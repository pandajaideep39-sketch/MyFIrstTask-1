const divide = ((a, b) => {
    return new Promise((resolve, reject) => {
        try {
            if (b === 0) {
                throw new Error("b is equal to zero.")
            }
            let division = a / b;
            console.log(division);
            resolve(division);
        }
        catch (err) {
            console.log("Error", err.message);
            reject(err);
        }
    })
})

divide(10, 10)
    .then((result) => {
        console.log("Dividing by 10 and 10:",result);
    })
    .catch((err) => {
        console.log("error occured;",  err.message);
    })

divide(10, 2)
    .then((result) => {
        console.log("Dividing by 10 and 2:",result);
    })
    .catch((err) => {
        console.log("error occured;",  err.message);
    })

divide(10, 0)
    .then((result) => {
        console.log("Dividing by 10 and 0:",result);
    })
    .catch((err) => {
        console.log("error occured;",  err.message);
    })

divide(20, 5)
    .then((result) => {
        console.log("Dividing by 20 and 5:",result);
    })
    .catch((err) => {
        console.log("error occured;",  err.message);
    })

divide(8, 0)
    .then((result) => {
        console.log("Dividing by 8 and 2:",result);
    })
    .catch((err) => {
        console.log("error occured;",  err.message);
    })