# ⚡ JavaScript Promise Division

A simple **JavaScript Promise-based division program** created to practice Promises, error handling, `resolve()`, `reject()`, and `try...catch`.

> **Note:** This project was developed as a learning exercise to understand how JavaScript Promises work and how errors can be handled using `try...catch` and `.catch()`.

---

## 📌 Features

* ➗ Performs division using a JavaScript Promise
* ✅ Resolves the Promise when the division is valid
* ❌ Rejects the Promise when the divisor is `0`
* ⚠️ Handles errors using `try...catch`
* 🔄 Uses `.then()` for successful results
* 🚨 Uses `.catch()` for rejected Promises
* 📝 Uses `err.message` for cleaner error output

---

## 🛠️ Technologies Used

* JavaScript (ES6)
* Promises
* Arrow Functions

---

## 📂 Project Structure

```text
JavaScript-Promise-Division/
│── script.js
└── README.md
```

---

## 🚀 How It Works

1. The `divide()` function accepts two numbers: `a` and `b`.
2. A new Promise is created using `resolve` and `reject`.
3. If `b` is not `0`, the numbers are divided and the Promise is resolved.
4. If `b` is `0`, an error is thrown.
5. The `catch` block catches the error and rejects the Promise.
6. `.then()` handles successful results.
7. `.catch()` handles errors.

---

## 💡 Error Handling

The program checks whether the divisor is `0`:

```javascript
if (b === 0) {
    throw new Error("b is equal to zero.");
}
```

The error is then handled using:

```javascript
catch (err) {
    console.log("Error", err.message);
    reject(err);
}
```

### Why `err.message`?

I initially used `err`, but it displayed a lot of extra error information in the console.

I used `err.message` instead so that only the error message I wrote is displayed:

```text
b is equal to zero.
```

This makes the console output cleaner and easier to understand.

---

## 📊 Test Cases

```text
divide(10, 10) → 1
divide(10, 2)  → 5
divide(10, 0)  → Error
divide(20, 5)  → 4
divide(8, 0)   → Error
```

---

## 🎯 Concepts Practiced

* Arrow Functions
* JavaScript Promises
* `resolve()`
* `reject()`
* `try...catch`
* `throw new Error()`
* `.then()`
* `.catch()`
* Error Objects
* `err.message`

---

## 📚 Learning Outcomes

Through this project, I learned:

* How to create and return a Promise
* How `resolve()` and `reject()` work
* How to handle errors using `try...catch`
* How `.then()` and `.catch()` handle Promise results
* How to create custom errors using `new Error()`
* The difference between logging `err` and `err.message`

---

## 🔮 Future Improvements

* 🔄 Rewrite the repeated `.then()` / `.catch()` blocks using `async/await`
* 🧮 Add support for other mathematical operations
* 📥 Accept user input instead of hardcoded values
* 🖥️ Create a simple UI for the calculator
* 🚨 Add more validation for invalid inputs

---

## ▶️ Getting Started

Clone the repository:

```bash
git clone https://github.com/your-username/javascript-promise-division.git
```

Navigate to the project folder:

```bash
cd javascript-promise-division
```

Run the JavaScript file using Node.js:

```bash
node script.js
```

---

## 👨‍💻 Author

**Jaideep**

Aspiring Full Stack Web Developer currently learning JavaScript, DSA, and modern web development through hands-on projects.

---

## ⭐ Support

If you found this project helpful, consider giving it a ⭐ on GitHub!
