console.log("To Check Numbers Are Even Or Odd!");


const a = 5;
const b = 10;
const c = 19;
const d = 124;

if(a % 2 == 0) {
    console.log( a,"is even");
}
else {
    console.log(a, "is odd");
}
if(b % 2 == 0) {
    console.log( b,"is even");
}
else {
    console.log(b, "is odd");
}
if(c % 2 == 0) {
    console.log( c,"is even");
}
else {
    console.log(c, "is odd");
}
if(d % 2 == 0) {
    console.log( d,"is even");
}
else {
    console.log(d, "is odd");
}
