# 🔢 Even or Odd Number Checker

A simple JavaScript program that checks whether given numbers are **even** or **odd** using the modulus (`%`) operator and conditional statements.

## 📌 Features

* Checks if a number is even or odd.
* Uses the modulus (`%`) operator.
* Demonstrates the use of `if...else` statements.
* Beginner-friendly JavaScript project.

## 🛠️ Technologies Used

* HTML (Optional, if connected to a webpage)
* JavaScript

## 📂 Project Structure

```text
Even-Odd-Checker/
│── index.html      # (Optional) HTML file
│── script.js       # JavaScript logic
│── README.md       # Project documentation
```

## 🚀 How It Works

1. Store one or more numbers in variables or an array.
2. Check each number using the condition:

```javascript
number % 2 === 0
```

3. If the remainder is `0`, the number is **Even**.
4. Otherwise, the number is **Odd**.
5. Display the result in the browser console.

## 💻 Example Code

```javascript
const numbers = [5, 10, 19, 124];

for (let number of numbers) {
    if (number % 2 === 0) {
        console.log(number + " is even");
    } else {
        console.log(number + " is odd");
    }
}
```

## 📤 Sample Output

```text
5 is odd
10 is even
19 is odd
124 is even
```

## 📖 Concepts Covered

* Variables (`const`)
* Arrays
* Loops (`for...of`)
* Conditional Statements (`if...else`)
* Modulus Operator (`%`)
* Console Output (`console.log()`)

## 🎯 Learning Outcome

This project helps beginners understand:

* How to determine whether a number is even or odd.
* How to use conditional logic in JavaScript.
* How to iterate through multiple values using loops.
* How to write clean and reusable code.

## 👨‍💻 Author

**Jaideep Bhookya**

Learning **MERN Stack**, **JavaScript**, and building beginner-friendly web development projects.
\
