// Maximum number in Array
// using sorted array instead of Unsorted one.
function maxNum(arr){
//     return arr[arr.length -1]
        console.log("Maximun Number:",arr[arr.length -1])
}
const arr1 = [1,2,3,4,5,6]
maxNum(arr1)

// Sum of all elements in array
function Sum(arr){
    let n = arr.length
    let sum = 0;
    for(let i = 0 ; i < n ; i++){
        sum += arr[i] 
    }
    console.log("Sum Of All Elemnets:",sum);
}
let arr2 = [2,4,1,5,6]
Sum(arr2)

//Count No . of Odd Numbers
const countOdd = function(arr) {
  let n = arr.length
    let count = 0;
    for(let i = 0 ; i < n ; i++){
        if(arr[i]%2 != 0){
            count++;
        }
    }
    console.log("Count Of All Odd Elements:",count);
};
let arr3 = [10,7,4,6,11,5]
countOdd(arr3);

 