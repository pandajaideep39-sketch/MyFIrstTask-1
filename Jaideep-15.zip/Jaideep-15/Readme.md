# 📊 JavaScript Array Operations

A simple JavaScript project that demonstrates basic array operations using functions. This project is beginner-friendly and helps in understanding how to work with arrays using loops, conditions, and functions.

---

## 📌 Features

* ✅ Find the maximum number in a **sorted array**
* ✅ Calculate the sum of all elements in an array
* ✅ Count the total number of odd elements in an array
* ✅ Simple and easy-to-understand JavaScript code
* ✅ Beginner-friendly logic with comments

---

## 🛠️ Technologies Used

* HTML (Optional for execution)
* JavaScript (ES6)

---

## 📂 Project Structure

```
Array-Operations/
│── script.js
│── README.md
```

---

## 🚀 How to Run

1. Clone this repository.

```bash
git clone https://github.com/your-username/your-repository.git
```

2. Open the project folder.

3. Run the JavaScript file:

   * Open it in **Visual Studio Code**.
   * Install the **Code Runner** extension or connect it to an HTML file.
   * You can also copy the code into your browser's Developer Console.

---

## 💻 Functions Included

### 1. Find Maximum Number

Returns the largest element from a **sorted array** by accessing the last index.

**Example**

```javascript
const arr1 = [1, 2, 3, 4, 5, 6];
```

**Output**

```
Maximum Number: 6
```

---

### 2. Sum of All Elements

Calculates the total sum of every element in the array using a loop.

**Example**

```javascript
const arr2 = [2, 4, 1, 5, 6];
```

**Output**

```
Sum Of All Elements: 18
```

---

### 3. Count Odd Numbers

Counts how many odd numbers are present in the given array.

**Example**

```javascript
const arr3 = [10, 7, 4, 6, 11, 5];
```

**Output**

```
Count Of All Odd Elements: 3
```

---

## 📚 Concepts Practiced

* Arrays
* Functions
* Loops (`for`)
* Conditional Statements (`if`)
* Arithmetic Operators
* Array Length Property
* Console Output

---

## 🔮 Future Improvements

* Find the maximum number in an **unsorted array**.
* Find the minimum element.
* Count even numbers.
* Calculate the average of array elements.
* Find the second largest element.
* Remove duplicate values.
* Accept user input dynamically.

---

## 🎯 Learning Outcome

This project helped reinforce the fundamentals of JavaScript by practicing array traversal, writing reusable functions, and implementing common array-based operations.

---

## 👨‍💻 Author

**Jaideep**

Feel free to explore, modify, and improve this project as you continue learning JavaScript.
