console.log("Compound Interest Calculator");

let P = 200000;
let r = 0.0772;
let n = 1;
let t = 3;

let A = P * (1 + ( r / n)) ** (n * t);

let Compound_Interest = Math.round(A - P);

console.log("Principle Amount:",P);
console.log("Rate Of Interest" , r);
console.log("Compounds Per Year:" ,n);
console.log("Years:",t);


console.log("Amount =",A.toFixed(2));
console.log(`The Compound Interest after ${t} years is: ${Compound_Interest}`);



