const students = [
  { Name: "Jaideep", Marks: 80, class: 1, Address: "Hyderabad" },
  { Name: "Harsha", Marks: 90, class: 2, Address: "Hyderabad" },
  { Name: "Akshith", Marks: 49, class: 3, Address: "Hyderabad" },
  { Name: "Kishore", Marks: 68, class: 4, Address: "Hyderabad" },
  { Name: "Shiva", Marks: 20, class: 5, Address: "Hyderabad" },
  { Name: "Seesaw", Marks: 12, class: 6, Address: "Hyderabad" },
  { Name: "Ramana", Marks: 32, class: 7, Address: "Hyderabad" },
  { Name: "Gopi", Marks: 97, class: 8, Address: "Hyderabad" },
  { Name: "Pavan", Marks: 27, class: 9, Address: "Hyderabad" },
  { Name: "Sathwik", Marks: 49, class: 10, Address: "Hyderabad" },
  { Name: "Ramesh", Marks: 23, class: 11, Address: "Hyderabad" },
  { Name: "Srishanth", Marks: 88, class: 12, Address: "Hyderabad" },
  { Name: "Suresh", Marks: 69, class: 13, Address: "Hyderabad" },
  { Name: "Teja", Marks: 67, class: 14, Address: "Hyderabad" },
  { Name: "Gaju", Marks: 80, class: 15, Address: "Hyderabad" },
  { Name: "Raghavendra", Marks: 56, class: 16, Address: "Hyderabad" },
  { Name: "Shyam", Marks: 45, class: 17, Address: "Hyderabad" },
  { Name: "Shylendra", Marks: 86, class: 18, Address: "Hyderabad" },
  { Name: "Firaz", Marks: 76, class: 19, Address: "Hyderabad" },
  { Name: "Amity", Marks: 35, class: 20, Address: "Hyderabad" },
];

const studentInfo = document.getElementById("student_info");
const resultsHeading = document.getElementById("resultsHeading");
const cardContainer = document.getElementById("cardContainer");

function renderCards(studentList) {
  let cards = "";

  studentList.forEach(function (student) {
    cards += `
      <div class="card">
        <h2>Name: ${student.Name}</h2>
        <p>Marks: ${student.Marks}</p>
        <p>Class: ${student.class}</p>
        <p>Address: ${student.Address}</p>
      </div>
    `;
  });

  cardContainer.innerHTML = cards;
}

renderCards(students);

studentInfo.addEventListener("input", function () {
  const searchValue = studentInfo.value.toLowerCase().trim();

  const filteredStudents = students.filter(function (student) {
    return student.Name.toLowerCase().startsWith(searchValue);
  });

  if (searchValue === "") {
    resultsHeading.style.display = "none";
  } else {
    resultsHeading.style.display = "block";
    resultsHeading.textContent = `Search Results for "${studentInfo.value}"`;
  }

  renderCards(filteredStudents);
});
