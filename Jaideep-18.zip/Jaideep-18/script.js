const myFunction = () => {
  const x = document.getElementById("input").value;

  document.getElementById("demo").innerHTML = "Hello, " + x;
};

const button = document.getElementById("btn");

button.addEventListener("click", myFunction);

button.addEventListener("click", myFunction);
const changeColour = (id) => {
  document.getElementById(id).style.background = id;
};
