# Interactive Greeting and Color Boxes

## 📌 About the Project

This project is a simple interactive webpage created using **HTML, CSS, and JavaScript**. The main purpose of this task is to understand how JavaScript can interact with HTML elements through the **DOM (Document Object Model)**.

The page contains a greeting header, four colored boxes, an input field, and a button. The user can enter their name and click the button to display a personalized greeting. The color boxes can also be clicked to fill them with their respective colors.

## 🎯 Objective

The objective of this assignment is to design a simple web page with interactive elements using HTML, CSS, and JavaScript.

The webpage includes:

* A header that initially displays **"Hello"**
* Four boxes containing the text **Red, Green, Blue, and Yellow**
* An input field to enter the user's name
* A **Greet** button
* Interactive functionality using JavaScript and DOM manipulation

## 📝 Tasks

The following tasks were completed as part of this assignment:

1. Created an HTML file containing the required elements.
2. Added a header with the initial text **"Hello"**.
3. Created four boxes named **Red, Green, Blue, and Yellow**.
4. Added an input field for entering the user's name.
5. Added a button to greet the user.
6. Used CSS to arrange and style the elements.
7. Used JavaScript to change the greeting when the button is clicked.
8. Used DOM manipulation to change the background color of each box when it is clicked.

## ⚙️ How It Works

### Greeting Functionality

When the user enters their name and clicks the **Greet** button, JavaScript gets the value from the input field using `.value`.

The header is then updated using `.innerHTML`.

For example:

```text
Hello

        ↓ Enter "Tanai" and click Greet ↓

Hello, Tanai
```

### Color Box Functionality

Each box has its own ID and passes that ID to the `changeColour()` function when clicked.

The function uses `document.getElementById()` to find the selected box and changes its background using JavaScript.

For example, clicking the **Red** box changes its background to red.

## 🛠️ Technologies Used

* **HTML5** – Used to create the structure of the webpage.
* **CSS3** – Used to style and arrange the elements.
* **JavaScript** – Used to add interaction and perform DOM manipulation.

## 📂 Project Structure

```text
project/
│
├── index.html
├── style.css
└── script.js
```

## 🧠 DOM Concepts Used

This project helped me practice some basic DOM concepts:

* `document.getElementById()` – to select HTML elements
* `.value` – to get the value entered in the input field
* `.innerHTML` – to change the greeting text
* `.addEventListener()` – to respond to the button click
* `.style.background` – to change the background color using JavaScript
* Functions – to organize the JavaScript functionality

## 📋 Instructions Followed

The assignment required the use of the **DOM to fill the boxes with their respective colors on click and to change the greeting text**.

The project follows these requirements by:

* Using DOM methods to access HTML elements
* Getting the user's name from the input field
* Updating the header after clicking the Greet button
* Changing each box's background color when it is clicked

## ▶️ How to Run

1. Open the project folder in VS Code.
2. Make sure `index.html`, `style.css`, and `script.js` are in the correct locations.
3. Open `index.html` in a browser, or use Live Server.
4. Enter a name in the input field.
5. Click **Greet** to see the greeting change.
6. Click any of the four boxes to change its background color.

## 📚 What I Learned

Through this assignment, I got more comfortable with connecting **HTML, CSS, and JavaScript** together.

The main thing I learned was how JavaScript can select elements from an HTML page and change their content or styling based on user actions. It also gave me practice with basic DOM manipulation and event handling.

## 🚀 Future Improvements

I can improve this project further by:

* Adding better styling and animations
* Adding a reset button
* Making the page responsive for smaller screens
* Adding more interactive elements
* Handling empty input more clearly

---

**Built as a practice project while learning JavaScript and DOM manipulation.**
