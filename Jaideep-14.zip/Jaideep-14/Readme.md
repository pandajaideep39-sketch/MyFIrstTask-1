# JavaScript Number Operations

This project is my practice assignment for learning JavaScript loops and conditions.

In this project I performed different operations on a number.

## Operations Performed

- Sum of first N numbers
- Multiplication table
- Prime number check
- Factors of a number
- Sum of digits
- Armstrong number check

## Technologies Used

- HTML
- JavaScript

## What I Learned

While doing this assignment, I learned how to use:

- for loops
- while loops
- if-else statements
- Mathematical operations
- Variables and console output