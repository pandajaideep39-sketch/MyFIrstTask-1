# Number Operations in JavaScript

This project demonstrates basic number operations in JavaScript using a single input number.  
The program calculates and prints:

1. **Sum of First N Numbers**  
   - Formula: `n * (n + 1) / 2`  
   - Example: For `n = 153`, the sum of the first 153 natural numbers is `11781`.

2. **Multiplication Table of N**  
   - Prints the table of `n` from 1 to 10.  
   - Example: For `n = 153`, it prints `153 x 1 = 153` up to `153 x 10 = 1530`.

3. **Prime Number Check**  
   - Determines if `n` is prime by checking divisibility from 2 to `n-1`.  
   - Example: `153` is **not prime** because it is divisible by 3, 9, 17, and 51.

4. **Factors of N**  
   - Lists all integers that divide `n` exactly.  
   - Example: Factors of `153` are `1, 3, 9, 17, 51, 153`.

5. **Armstrong Number Check**  
   - Extracts digits, cubes each digit, and sums them.  
   - Compares the sum with the original number.  
   - Example: `153` is an **Armstrong number** because `1³ + 5³ + 3³ = 153`.

---

## Example Output (for `n = 153`)

