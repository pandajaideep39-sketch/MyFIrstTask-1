let num = 153;
console.log("Number:", num);

console.log("\nSum of First N Numbers:");
let sumFirstN = num * ((num + 1) / 2);
console.log(sumFirstN);

console.log("\nTable of N:");
for (let i = 1; i <= 10; i++) {
    console.log(num + " x " + i + " = " + (num * i));
}

console.log("\nChecking Prime Number:");
let isPrime = true;
for (let i = 2; i <= num - 1; i++) {
    if (num % i === 0) {
        isPrime = false;
        break;
    }
}
if (isPrime) {
    console.log(num, "is Prime.");
} else {
    console.log(num, "is not Prime.");
}

console.log("\nFactors of Number:");
for (let i = 1; i <= num; i++) {
    if (num % i === 0) {
        console.log(i, "is a Factor");
    }
}

console.log("\nArmstrong Number:");
let originalNum = num;
let armstrongSum = 0;

while (num > 0) {
    let digit = num % 10;
    armstrongSum += digit ** 3;
    num = Math.floor(num / 10);
}

if (armstrongSum === originalNum) {
    console.log(originalNum, "is an Armstrong Number.");
} else {
    console.log(originalNum, "is not an Armstrong Number.");
}
