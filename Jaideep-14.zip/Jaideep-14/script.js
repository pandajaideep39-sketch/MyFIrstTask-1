let num = 153;
console.log("Number:", num);

let FirstNsum = 0;
for (let i = 1; i <= num; i++) {
    FirstNsum += i;
}

console.log("Sum of First n Numbers:", FirstNsum);

console.log("\nTable:");
for (let i = 1; i <= 10; i++) {
    console.log(num + " x " + i + " = " + (num * i));
}

console.log("\nPrime Number Check:");
let isPrime = true;
for (let i = 2; i <= num - 1; i++) {
    if (num % i === 0) {
        isPrime = false;
        break;
    }
}
if (isPrime) {
    console.log(num, "is Prime.");
} else {
    console.log(num, "is not Prime.");
}

console.log("\nFactors of Number:");
for (let i = 1; i <= num; i++) {
    if (num % i === 0) {
        console.log(i, "is a Factor");
    }
}

console.log("\nSum of Digits:");

let temp = num;
let digit_Sum = 0;
while (temp > 0) {
    let digit = temp % 10;
    digit_Sum = digit_Sum + digit;
    temp = Math.floor(temp / 10);
}
console.log("Sum of digits is:", digit_Sum);

console.log("\nArmstrong Number:");
let original_num = num;
let armstrong_num = 0;

while (num > 0) {
    let digit = num % 10;
    armstrong_num += (digit ** 3);
    num = Math.floor(num / 10);
}

if (armstrong_num == original_num) {
    console.log(original_num, "is an Armstrong Number.");
} else {
    console.log(original_num, "is not an Armstrong Number.");
}
