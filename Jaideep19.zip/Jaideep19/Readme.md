# Laundry Service Booking

A simple laundry service booking interface built with HTML, CSS, and JavaScript.

The project allows users to browse available laundry services, add services to a cart, view the total amount, and submit a booking.

## Features

- Clean and simple navigation bar
- Browse laundry services one by one
- Skip unwanted services
- Add services to the cart
- Dynamic cart updates
- Automatic total amount calculation
- Empty cart state
- Booking form with user details
- Booking confirmation message
- Cart reset after booking
- Responsive layout

## Tech Stack

- HTML5
- CSS3
- JavaScript
- Lucide Icons

## How It Works

The available services are stored in a JavaScript array containing the service name, price, and image.

The user can move through the services using the **Skip Item** button or add the current service using **Add Item**.

Added services are displayed in the cart on the left side of the page, and the total amount is updated automatically.

Once at least one service has been added, the user can fill in their details and click **Book Now** to complete the booking.

## Project Structure

Laundry-Service/
│
├── index.html
├── style.css
├── script.js
└── images/
    ├── Drycleaning.jpg
    ├── Ironing.jpg
    └── StainRemoval.jpg

    What I Learned

This project helped me practice DOM manipulation and basic JavaScript logic.

--> I worked with:

Arrays and objects
Array indexing
DOM selection and manipulation
Event listeners
Dynamic content rendering
forEach() loops
Adding items to arrays using push()
Calculating values dynamically
Managing application state with JavaScript
Future Improvements
Add remove item functionality
Add service quantity controls
Add proper form validation
Make the navigation links functional
Add backend support for storing bookings
Add user authentication
Improve mobile responsiveness
