document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});

const services = [
  {
    name: "Dry Cleaning",
    price: 200,
    img: "./images/Drycleaning.jpg",
  },
  {
    name: "Ironing",
    price: 300,
    img: "/images/Ironing.jpg",
  },
  {
    name: "Stain Removal",
    price: 500,
    img: "./images/StainRemoval.jpg",
  },
];

const serviceImg = document.getElementById("service-img");
const serviceTitle = document.getElementById("service-title");
const servicePrice = document.getElementById("service-price");

// serviceImg.src = services.img;
// serviceTitle.textContent = services.name;
// servicePrice.textContent = `₹ ${services.price}`;

let currentIndex = 0;
let cart = [];

function renderCurrentServices() {
  if (currentIndex >= services.length) {
    currentIndex = 0;
  }

  const currentService = services[currentIndex];
  serviceTitle.textContent = currentService.name;
  servicePrice.textContent = `₹ ${currentService.price}`;
  serviceImg.src = currentService.img;
}

const skipBtn = document.getElementById("skip-btn");
skipBtn.addEventListener("click", () => {
  currentIndex = currentIndex + 1;
  renderCurrentServices();
});

let addBtn = document.getElementById("add-btn");
addBtn.addEventListener("click", () => {
  const currentService = services[currentIndex];
  cart.push(currentService);
  renderCart();
  console.log(cart);
  currentIndex = currentIndex + 1;
  renderCurrentServices();
});

const cartBody = document.getElementById("cart-body");
function renderCart() {
  cartBody.innerHTML = "";
  cart.forEach((item, i) => {
    const row = document.createElement("tr");
    row.innerHTML = `<td>${i + 1}</td><td>${item.name}</td><td>₹${item.price}</td>`;
    cartBody.appendChild(row);
  });
  let total = 0;
  cart.forEach((item) => {
    total = total + item.price;
  });
  totalAmount.textContent = `₹ ${total}`;
  if (cart.length === 0) {
    emptyState.style.display = "flex";
  } else {
    emptyState.style.display = "none";
  }
}

const totalAmount = document.getElementById("total-amount");

const emptyState = document.getElementById("empty-state");

renderCurrentServices();

let bookBtn = document.getElementById("book-btn");
let bookMessage = document.getElementById("book-message");

bookBtn.addEventListener("click", () => {
  if (cart.length === 0) {
    bookMessage.textContent = "Add items to the cart to book";
    return;
  }
  bookMessage.textContent = "Thank you, we will get back to you soon";
  cart = [];
  currentIndex = 0;
  renderCart();
  renderCurrentServices();
});
